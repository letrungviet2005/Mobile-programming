plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.google.gms.google.services)
}

android {
    namespace = "com.example.lab07"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.lab07"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
    packagingOptions {
        exclude ("META-INF/DEPENDENCIES")
    }


}


dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation("androidx.compose.material3:material3:1.0.1")
    implementation("androidx.compose.material:material:1.3.1")
    implementation("androidx.compose.material3:material3-window-size-class:1.0.1")
    implementation(platform("com.google.firebase:firebase-bom:32.8.1"))
    implementation(libs.firebase.firestore)
    implementation(libs.firebase.auth)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services.auth)
    implementation(libs.googleid)
    implementation(libs.firebase.storage)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
    implementation("io.coil-kt:coil-compose:2.2.2")
    implementation("com.google.firebase:firebase-storage-ktx:20.3.0")

    implementation ("androidx.navigation:navigation-compose:2.7.7")

    // Google Sign-In
    implementation ("com.google.android.gms:play-services-auth:20.7.0")

    // Google API Client
    implementation ("com.google.api-client:google-api-client-android:1.33.0")
    implementation ("com.google.http-client:google-http-client-gson:1.43.3")

    // Google Drive API
    implementation ("com.google.apis:google-api-services-drive:v3-rev197-1.25.0")

    // Gson để xử lý JSON
    implementation ("com.google.code.gson:gson:2.8.9")


    implementation("com.squareup.okhttp3:okhttp:4.9.3")


    implementation ("com.squareup.okhttp3:okhttp:4.9.3")
    implementation ("org.json:json:20210307")

    implementation("androidx.navigation:navigation-compose:2.7.6")

}