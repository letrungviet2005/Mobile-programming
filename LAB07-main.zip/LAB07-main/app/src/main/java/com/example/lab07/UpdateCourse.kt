package com.example.lab07


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

import com.example.lab07.ui.theme.FirebaseprojectTheme
import android.content.Context
import android.content.Intent

import android.text.TextUtils

import android.widget.Toast


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.lab07.ui.theme.greenColor

import com.google.firebase.firestore.FirebaseFirestore


class UpdateCourse : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FirebaseprojectTheme {
                // A surface container using the 'background' color from the theme
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.background
                        ) {

                            Scaffold(
                                // in scaffold we are specifying the top bar.
                                topBar = {
                                    // inside top bar we are specifying
                                    // background color.
                                    TopAppBar(backgroundColor = greenColor,
                                        // along with that we are specifying
                                        // title for our top bar.
                                        title = {
                                            // in the top bar we are specifying
                                            // title as a text
                                            Text(
                                                // on below line we are specifying
                                                // text to display in top app bar
                                                text = "GFG",
                                                // on below line we are specifying
                                                // modifier to fill max width
                                                modifier = Modifier.fillMaxWidth(),
                                                // on below line we are specifying
                                                // text alignment
                                                textAlign = TextAlign.Center,
                                                // on below line we are specifying
                                                // color for our text.
                                                color = Color.White
                                            )
                                        })
                                }) { innerPadding ->
                                Text(
                                    modifier = Modifier.padding(innerPadding),
                                    text = "Cap nhat du lieu."
                                )

                                // on below line getting data from our database
                                // on below line we are calling method to display UI
                                firebaseUI(
                                    LocalContext.current,
                                    intent.getStringExtra("courseName"),
                                    intent.getStringExtra("courseDuration"),
                                    intent.getStringExtra("courseDescription"),
                                    intent.getStringExtra("courseID")
                                )


                            }
                        }
            }
        }
    }


    // cap nhat
    @Composable
    fun firebaseUI(
        context: Context,
        name: String?,
        duration: String?,
        description: String?,
        courseID: String?
    ) {
        val courseName = remember { mutableStateOf(name ?: "") }
        val courseDuration = remember { mutableStateOf(duration ?: "") }
        val courseDescription = remember { mutableStateOf(description ?: "") }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CustomTextField(label = "Course Name", state = courseName)
            Spacer(modifier = Modifier.height(10.dp))
            CustomTextField(label = "Course Duration", state = courseDuration)
            Spacer(modifier = Modifier.height(10.dp))
            CustomTextField(label = "Course Description", state = courseDescription)
            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (TextUtils.isEmpty(courseName.value)) {
                        showToast(context, "Please enter course name")
                    } else if (TextUtils.isEmpty(courseDuration.value)) {
                        showToast(context, "Please enter course duration")
                    } else if (TextUtils.isEmpty(courseDescription.value)) {
                        showToast(context, "Please enter course description")
                    } else {
                        updateDataToFirebase(
                            courseID,
                            courseName.value,
                            courseDuration.value,
                            courseDescription.value,
                            context
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Update Data", modifier = Modifier.padding(8.dp))
            }
        }
    }

    @Composable
    fun CustomTextField(label: String, state: MutableState<String>) {
        TextField(
            value = state.value,
            onValueChange = { state.value = it },
            placeholder = { Text(text = "Enter your $label") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(color = Color.Black, fontSize = 15.sp),
            singleLine = true,
            trailingIcon = {
                if (state.value.isNotEmpty()) {
                    IconButton(onClick = { state.value = "" }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            }
        )
    }

    private fun updateDataToFirebase(
        courseID: String?,
        name: String?,
        duration: String?,
        description: String?,
        context: Context
    ) {
        val updatedCourse = Course(courseID, name, duration, description)
        val db = FirebaseFirestore.getInstance()

        db.collection("Courses").document(courseID ?: "").set(updatedCourse)
            .addOnSuccessListener {
                showToast(context, "Course updated successfully")
                context.startActivity(Intent(context, CourseDetailsActivity::class.java))
            }
            .addOnFailureListener {
                showToast(context, "Failed to update course: ${it.message}")
            }
    }

    private fun showToast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
