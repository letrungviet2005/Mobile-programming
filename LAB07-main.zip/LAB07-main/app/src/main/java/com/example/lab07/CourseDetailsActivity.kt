package com.example.lab07

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.*
import coil.compose.AsyncImage
import com.example.lab07.ui.theme.FirebaseprojectTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.material.icons.filled.Delete


class CourseDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Đảm bảo gọi super.onCreate để tránh lỗi
        setContent {
            FirebaseprojectTheme {
                val navController = rememberNavController()
                CourseNavHost(navController)
            }
        }
    }
}

@Composable
fun CourseNavHost(navController: NavController) {
    val courseList = remember { mutableStateListOf<Course>() }
    val navController = rememberNavController()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current
    val user = FirebaseAuth.getInstance().currentUser

    // Tải dữ liệu từ Firestore
    LaunchedEffect(user) {
        user?.let {
            db.collection("courses")
                .whereEqualTo("userID", it.uid)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    courseList.clear()
                    for (doc in querySnapshot) {
                        val course = doc.toObject(Course::class.java).apply {
                            courseID = doc.id
                        }
                        courseList.add(course)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(context, "Lỗi khi tải dữ liệu", Toast.LENGTH_SHORT).show()
                }
        }
    }

    NavHost(navController, startDestination = "course_list") {
        composable("course_list") {
            CourseListScreen(courseList, navController)
        }
        composable("course_detail/{courseID}") { backStackEntry ->
            val courseID = backStackEntry.arguments?.getString("courseID")
            val course = courseList.find { it.courseID == courseID }
            if (course != null) {
                CourseDetailScreen(course, navController, courseList)
            }
        }
    }
}

@Composable
fun CourseListScreen(courseList: SnapshotStateList<Course>, navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color.White),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (courseList.isEmpty()) {
            Text(text = "Không có ghi chú nào!", fontSize = 18.sp)
        } else {
            LazyColumn {
                items(courseList) { course ->
                    CourseItem(course, navController)
                }
            }
        }
    }
}

@Composable
fun CourseItem(course: Course, navController: NavController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { navController.navigate("course_detail/${course.courseID}") }
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = course.imageUrl ?: "https://via.placeholder.com/100",
                contentDescription = "Course Image",
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = course.name ?: "Không có tên", fontSize = 20.sp)
                Text(text = course.description ?: "Không có mô tả", fontSize = 15.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseDetailScreen(course: Course, navController: NavController, courseList: SnapshotStateList<Course>) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()
    val user = FirebaseAuth.getInstance().currentUser

    var title by remember { mutableStateOf(course.name ?: "") }
    var description by remember { mutableStateOf(course.description ?: "") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chỉnh sửa ghi chú") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val updatedCourse = course.copy(name = title, description = description)

                        db.collection("courses").document(course.courseID!!)
                            .set(
                                hashMapOf(
                                    "name" to title,
                                    "description" to description,
                                    "imageUrl" to course.imageUrl,
                                    "userID" to (user?.uid ?: "unknown")
                                )
                            )
                            .addOnSuccessListener {
                                Toast.makeText(context, "Đã lưu!", Toast.LENGTH_SHORT).show()

                                // Cập nhật `savedStateHandle`
                                navController.previousBackStackEntry?.savedStateHandle?.set("updatedCourse", updatedCourse)

                                // Quay lại danh sách
                                navController.popBackStack()
                            }
                            .addOnFailureListener {
                                Toast.makeText(context, "Lỗi khi lưu!", Toast.LENGTH_SHORT).show()
                            }
                    }) {
                        Icon(Icons.Default.Check, contentDescription = "Lưu")
                    }

                    // Nút xóa
                    IconButton(onClick = {
                        deleteCourseFromFirebase(course.courseID!!, context) {
                            // Sau khi xóa, refresh danh sách khóa học
                            courseList.removeIf { it.courseID == course.courseID }
                            navController.popBackStack() // Quay lại danh sách
                        }
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            TextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            AsyncImage(
                model = course.imageUrl ?: "https://via.placeholder.com/300",
                contentDescription = "Course Image",
                modifier = Modifier.fillMaxWidth().height(200.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
