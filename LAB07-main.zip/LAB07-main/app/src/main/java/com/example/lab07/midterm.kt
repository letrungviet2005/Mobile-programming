package com.example.lab07

class midterm {
}