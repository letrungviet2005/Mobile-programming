package com.example.lab07
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.TopAppBar
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.compose.rememberImagePainter
import com.example.lab07.ui.theme.FirebaseprojectTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.Request
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

import androidx.compose.material3.TextField
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding


import androidx.compose.foundation.Image


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser == null) {
            startActivity(Intent(this, Login::class.java))
            finish()
        } else {
            setContent {
                FirebaseprojectTheme {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Notepad") },

            )
        }
    ) { innerPadding ->
        Column(Modifier.padding(innerPadding)) {
            Text(text = "Xin chào bạn!")
            FirebaseUI(context)
        }
    }

}

@Composable
fun CustomTextField(placeholder: String, textState: MutableState<String>) {
    TextField(
        value = textState.value,
        onValueChange = { textState.value = it },
        placeholder = { Text(text = placeholder) },
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        textStyle = TextStyle(color = Color.Black, fontSize = 15.sp),
        singleLine = true
    )
}

@Composable
fun FirebaseUI(context: Context) {
    val courseName = remember { mutableStateOf("") }
    val courseDescription = remember { mutableStateOf("") }
    val imageUri = remember { mutableStateOf<Uri?>(null) }
    val auth = FirebaseAuth.getInstance()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        imageUri.value = it
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5)) // Màu nền nhẹ nhàng
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Thêm Ghi Chú",
            style = TextStyle(fontSize = 24.sp, color = Color.Black),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                CustomTextField(
                    placeholder = "Nhập tiêu đề ghi chú",
                    textState = courseName
                )

                Spacer(modifier = Modifier.height(10.dp))

                CustomTextField(
                    placeholder = "Nhập mô tả ghi chú",
                    textState = courseDescription,
                    modifier = Modifier.height(120.dp) // Cao hơn để nhập nội dung dài
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { launcher.launch("image/*") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Text(text = "Chọn ảnh")
                }

                imageUri.value?.let {
                    Spacer(modifier = Modifier.height(10.dp))
                    Image(
                        painter = rememberImagePainter(it),
                        contentDescription = "Hình ảnh đã chọn",
                        modifier = Modifier
                            .size(150.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Gray)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (courseName.value.isEmpty() || courseDescription.value.isEmpty()) {
                            Toast.makeText(context, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show()
                        } else {
                            addDataToFirebase(courseName.value, courseDescription.value, imageUri.value!!, context)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Text(text = "Thêm ghi chú", modifier = Modifier.padding(8.dp), color = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val intent = Intent(context, CourseDetailsActivity::class.java)
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF009688)), // Xanh ngọc
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            Text(text = "Xem ghi chú", modifier = Modifier.padding(8.dp), color = Color.White)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                auth.signOut()
                context.startActivity(Intent(context, Login::class.java))
                (context as? ComponentActivity)?.finish()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            Text("Đăng xuất", color = Color.White)
        }
    }
}


fun addDataToFirebase(
    name: String,
    description: String,
    imageUri: Uri,
    context: Context
) {
    uploadToCloudinary(imageUri, context, { imageUrl ->
        val db = FirebaseFirestore.getInstance()
        val user = FirebaseAuth.getInstance().currentUser
        val courseData = hashMapOf(
            "name" to name,
            "description" to description,
            "imageUrl" to imageUrl,
            "userID" to (user?.uid ?: "unknown") // Lưu ID người dùng nếu
        )

        db.collection("courses")
            .add(courseData)
            .addOnSuccessListener {
                Toast.makeText(context, "Thêm ghi chú thành công", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Lỗi", Toast.LENGTH_SHORT).show()
            }
    }, {
        Toast.makeText(context, "Lỗi khi upload ảnh lên Cloudinary", Toast.LENGTH_SHORT).show()
    })
}

fun uploadToCloudinary(imageUri: Uri, context: Context, onSuccess: (String) -> Unit, onFailure: () -> Unit) {
    val cloudName = "dlygiqmtc"
    val uploadPreset = "KTGK112"

    val contentResolver = context.contentResolver
    val inputStream = contentResolver.openInputStream(imageUri)
    val byteArray = inputStream?.readBytes()
    inputStream?.close()

    val requestBody = byteArray?.let { RequestBody.create("image/*".toMediaTypeOrNull(), it) }
    val multipartBody = requestBody?.let {
        MultipartBody.Part.createFormData("file", "upload.jpg", it)
    }

    val requestBodyMap = MultipartBody.Builder()
        .setType(MultipartBody.FORM)
        .addFormDataPart("upload_preset", uploadPreset)
        .addPart(multipartBody!!)
        .build()

    val client = OkHttpClient()
    val request = Request.Builder()
        .url("https://api.cloudinary.com/v1_1/$cloudName/image/upload")
        .post(requestBodyMap)
        .build()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            (context as ComponentActivity).runOnUiThread {
                Toast.makeText(context, "Lỗi khi upload ảnh", Toast.LENGTH_SHORT).show()
            }
            onFailure()
        }

        override fun onResponse(call: Call, response: Response) {
            val jsonResponse = JSONObject(response.body?.string() ?: "{}")
            val imageUrl = jsonResponse.getString("secure_url")

            (context as ComponentActivity).runOnUiThread {
                Toast.makeText(context, "Upload ảnh thành công", Toast.LENGTH_SHORT).show()
            }
            onSuccess(imageUrl)
        }
    })
}



@Composable
fun CustomTextField(placeholder: String, textState: MutableState<String>, modifier: Modifier = Modifier) {
    TextField(
        value = textState.value,
        onValueChange = { textState.value = it },
        placeholder = { Text(text = placeholder, color = Color.Gray) },
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
            .padding(horizontal = 10.dp),
        textStyle = TextStyle(color = Color.Black, fontSize = 15.sp),
        singleLine = true
    )
}
