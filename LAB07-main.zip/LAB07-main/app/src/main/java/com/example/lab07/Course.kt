package com.example.lab07

data class Course(
 var   courseID: String?,
var name: String? = "",
var description: String? = "",
 var imageUrl: String? = null
){
 constructor() : this(null, "", "", "")
}
